AetherChess — Self-Contained Static HTML (Standard Quality)

How to deploy:
1. Unzip this archive.
2. Upload index.html to any static HTML host or HTML runner
   (GitHub Pages, Netlify, Vercel, Cloudflare Pages, Apache, Nginx, cPanel, S3, or open directly in your browser).

Everything (compiled CSS & JS) is bundled inside index.html — no extra folders or build step needed.
